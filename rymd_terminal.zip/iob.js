function welcome() {
	window.location = "omoss.html"
}